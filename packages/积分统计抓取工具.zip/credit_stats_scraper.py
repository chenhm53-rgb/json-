"""
Cookie 积分统计工具

用途：
1. 读取 JSON 文件中的多条记录；
2. 使用每条记录里的唯一标识符拼接网页地址；
3. 打开网页并读取积分元素；
4. 按积分值统计数量；
5. 输出明细 JSON、明细 CSV、积分汇总 JSON、积分汇总 CSV。

第一次使用前，请先修改下面“需要修改的配置”区域。
"""

from __future__ import annotations

import csv
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Optional, Union
from urllib.parse import quote, urlparse

from playwright.sync_api import BrowserContext, Page, TimeoutError as PlaywrightTimeoutError, sync_playwright


# ============================================================
# 需要修改的配置
# ============================================================

# JSON 文件路径。可以填写绝对路径，也可以填写与本脚本同目录的文件名。
INPUT_JSON = Path("cookies.json")

# JSON 中用来唯一标识每条记录的字段名。
# 例如你的数据是 {"cookie_id": "abc123"}，这里就填写 "cookie_id"。
IDENTIFIER_FIELD = "cookie_id"

# 页面 URL 模板。
# {identifier} 会自动替换成每条 JSON 记录中的唯一标识符。
URL_TEMPLATE = "https://example.com/dashboard?cookie_id={identifier}"

# 积分所在元素的 CSS 选择器。
# 例如 HTML 是 <span class="user-credit">100</span>，就填写 ".user-credit"。
POINTS_SELECTOR = ".user-credit"

# 是否需要登录。
# True：脚本会打开可见浏览器，你手动登录后回到终端按回车，脚本再开始抓取。
# False：脚本直接访问页面。
NEED_LOGIN = False

# 需要登录时填写登录页面；不需要登录时可以保持空字符串。
LOGIN_URL = "https://example.com/login"

# 等待网页加载积分的最长时间，单位毫秒。
WAIT_FOR_POINTS_MS = 15000

# 页面打开后额外等待的时间，单位秒。有些网页需要异步请求积分。
EXTRA_WAIT_SECONDS = 1.5

# 是否显示浏览器窗口。
# 需要手动登录时必须为 True。
HEADLESS = False

# 输出目录。
OUTPUT_DIR = Path("credit_stats_output")


# ============================================================
# 通用工具函数
# ============================================================


def load_json_records(path: Path) -> list[dict[str, Any]]:
    """读取 JSON，并兼容常见的数组、data 数组、records 数组结构。"""
    if not path.exists():
        raise FileNotFoundError(f"找不到 JSON 文件：{path.resolve()}")

    with path.open("r", encoding="utf-8-sig") as file:
        data = json.load(file)

    if isinstance(data, list):
        records = data
    elif isinstance(data, dict):
        records = None
        for key in ("records", "items", "data", "cookies", "accounts"):
            if isinstance(data.get(key), list):
                records = data[key]
                break
        if records is None:
            records = [data]
    else:
        raise ValueError("JSON 顶层必须是数组或对象")

    valid_records = [item for item in records if isinstance(item, dict)]
    if not valid_records:
        raise ValueError("JSON 中没有找到对象记录")
    return valid_records


def first_value(record: dict[str, Any], names: tuple[str, ...]) -> Any:
    """从多个候选字段中取第一个非空值。"""
    for name in names:
        value = record.get(name)
        if value not in (None, "", [], {}):
            return value
    return None


def cookie_header_to_pairs(cookie_header: str) -> list[tuple[str, str]]:
    """把 name=value; name2=value2 形式的 Cookie 请求头拆成键值对。"""
    pairs: list[tuple[str, str]] = []
    for part in str(cookie_header).split(";"):
        if "=" not in part:
            continue
        name, value = part.split("=", 1)
        name = name.strip()
        value = value.strip()
        if name:
            pairs.append((name, value))
    return pairs


def cookies_for_record(record: dict[str, Any], url: str) -> list[dict[str, Any]]:
    """提取记录中的 cookie，并转换为 Playwright 可用的格式。

    支持：
    - cookie / cookie_string / cookie_header：Cookie 请求头字符串
    - cookies：[{"name": "...", "value": "...", "domain": "..."}]
    """
    host = urlparse(url).hostname or ""
    cookie_data = first_value(record, ("cookies", "cookie_objects"))

    if isinstance(cookie_data, list):
        result: list[dict[str, Any]] = []
        for item in cookie_data:
            if not isinstance(item, dict) or not item.get("name"):
                continue
            result.append(
                {
                    "name": str(item["name"]),
                    "value": str(item.get("value", "")),
                    "domain": str(item.get("domain") or host),
                    "path": str(item.get("path") or "/"),
                }
            )
        return result

    cookie_header = first_value(record, ("cookie", "cookie_string", "cookie_header", "Cookie"))
    if not isinstance(cookie_header, str):
        return []

    return [
        {"name": name, "value": value, "domain": host, "path": "/"}
        for name, value in cookie_header_to_pairs(cookie_header)
    ]


Number = Union[int, float]


def extract_number(text: str) -> Optional[Number]:
    """从积分元素文本中提取第一个数字，支持 1,234 和 12.5。"""
    match = re.search(r"(?<![A-Za-z0-9])\d+(?:,\d{3})*(?:\.\d+)?", text)
    if not match:
        return None

    raw = match.group(0).replace(",", "")
    number = float(raw)
    return int(number) if number.is_integer() else number


def format_number(number: Number) -> str:
    """让汇总表中的数字更容易阅读。"""
    if isinstance(number, int) or float(number).is_integer():
        return f"{int(number):,}"
    return f"{number:,.2f}"


def identifier_text(record: dict[str, Any], index: int) -> str:
    """读取唯一标识符，并统一转成字符串。"""
    value = record.get(IDENTIFIER_FIELD)
    if value in (None, ""):
        raise ValueError(f"第 {index} 条记录缺少字段：{IDENTIFIER_FIELD}")
    return str(value)


def build_url(identifier: str) -> str:
    """把唯一标识符放进 URL 模板。"""
    return URL_TEMPLATE.replace("{identifier}", quote(identifier, safe=""))


def safe_error_message(error: Exception) -> str:
    """返回适合写入结果文件的简短错误信息，不输出 cookie 内容。"""
    message = str(error).replace("\n", " ").strip()
    return message[:300] or error.__class__.__name__


def read_points(page: Page) -> Number:
    """等待积分元素出现并读取积分数字。"""
    locator = page.locator(POINTS_SELECTOR).first
    locator.wait_for(state="visible", timeout=WAIT_FOR_POINTS_MS)
    text = locator.inner_text(timeout=WAIT_FOR_POINTS_MS)
    points = extract_number(text)
    if points is None:
        raise ValueError(f"找到了积分元素，但其中没有数字。元素文本：{text[:120]}")
    return points


def add_record_cookies(context: BrowserContext, record: dict[str, Any], url: str) -> None:
    """将当前记录携带的 cookie 加入浏览器上下文。"""
    cookies = cookies_for_record(record, url)
    if cookies:
        # 非登录模式下每条记录使用自己的 cookie，避免上一条记录串入下一条。
        # 手动登录模式保留登录会话，只补充当前记录的 cookie。
        if not NEED_LOGIN:
            context.clear_cookies()
        context.add_cookies(cookies)


def scrape_one(page: Page, context: BrowserContext, record: dict[str, Any], index: int) -> dict[str, Any]:
    """抓取一条记录，并返回不包含 cookie 原文的明细。"""
    identifier = identifier_text(record, index)
    url = build_url(identifier)
    result: dict[str, Any] = {
        "index": index,
        "identifier": identifier,
        "url": url,
        "status": "failed",
        "points": None,
        "error": "",
    }

    try:
        add_record_cookies(context, record, url)
        page.goto(url, wait_until="domcontentloaded", timeout=WAIT_FOR_POINTS_MS)
        page.wait_for_timeout(int(EXTRA_WAIT_SECONDS * 1000))
        points = read_points(page)
        result["status"] = "success"
        result["points"] = points
    except Exception as error:
        result["error"] = safe_error_message(error)

    return result


def write_json(path: Path, data: Any) -> None:
    """以 UTF-8 写入 JSON。"""
    with path.open("w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    """以 UTF-8 with BOM 写入 CSV，便于 Windows Excel 正确识别中文。"""
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    """生成积分分组和总体统计。"""
    success_points = [row["points"] for row in results if row["status"] == "success" and row["points"] is not None]
    counter = Counter(success_points)
    sorted_groups = [
        {"points": points, "count": counter[points]}
        for points in sorted(counter, key=float)
    ]

    summary: dict[str, Any] = {
        "total_cookies": len(results),
        "success_count": len(success_points),
        "failed_count": len(results) - len(success_points),
        "minimum_points": min(success_points) if success_points else None,
        "maximum_points": max(success_points) if success_points else None,
        "average_points": statistics.mean(success_points) if success_points else None,
        "groups": sorted_groups,
    }
    return summary


def print_summary(summary: dict[str, Any]) -> None:
    """在终端打印清晰的中文统计表。"""
    print("\n积分统计结果")
    print("=" * 48)
    print(f"总记录数：{summary['total_cookies']}")
    print(f"成功读取：{summary['success_count']}")
    print(f"读取失败：{summary['failed_count']}")
    print(f"最低积分：{format_number(summary['minimum_points']) if summary['minimum_points'] is not None else '无'}")
    print(f"最高积分：{format_number(summary['maximum_points']) if summary['maximum_points'] is not None else '无'}")
    print(f"平均积分：{format_number(summary['average_points']) if summary['average_points'] is not None else '无'}")
    print("\n按积分从低到高")
    print("积分\t记录数")
    print("-" * 24)
    for group in summary["groups"]:
        print(f"{format_number(group['points'])}\t{group['count']}")


def main() -> int:
    """程序入口。"""
    if "example.com" in URL_TEMPLATE or POINTS_SELECTOR == ".user-credit":
        print("提示：请先打开脚本，修改顶部的 INPUT_JSON、IDENTIFIER_FIELD、URL_TEMPLATE 和 POINTS_SELECTOR。")

    try:
        records = load_json_records(INPUT_JSON)
    except Exception as error:
        print(f"读取 JSON 失败：{safe_error_message(error)}")
        return 1

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=HEADLESS)
        context = browser.new_context()
        page = context.new_page()

        try:
            if NEED_LOGIN:
                if not LOGIN_URL:
                    raise ValueError("NEED_LOGIN=True 时必须填写 LOGIN_URL")
                page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=WAIT_FOR_POINTS_MS)
                print("浏览器已打开登录页面，请在浏览器中完成登录。")
                input("登录完成后回到这里按回车，开始抓取：")

            total = len(records)
            for index, record in enumerate(records, start=1):
                print(f"正在处理 {index}/{total} ...")
                result = scrape_one(page, context, record, index)
                results.append(result)
                if result["status"] == "success":
                    print(f"  成功，积分：{format_number(result['points'])}")
                else:
                    print(f"  失败：{result['error']}")
        finally:
            context.close()
            browser.close()

    summary = build_summary(results)
    write_json(OUTPUT_DIR / "抓取明细.json", results)
    write_csv(
        OUTPUT_DIR / "抓取明细.csv",
        results,
        ["index", "identifier", "url", "status", "points", "error"],
    )
    write_json(OUTPUT_DIR / "积分汇总.json", summary)
    write_csv(OUTPUT_DIR / "积分汇总.csv", summary["groups"], ["points", "count"])
    print_summary(summary)
    print(f"\n结果文件已保存到：{OUTPUT_DIR.resolve()}")
    return 0 if summary["success_count"] else 2


if __name__ == "__main__":
    sys.exit(main())
